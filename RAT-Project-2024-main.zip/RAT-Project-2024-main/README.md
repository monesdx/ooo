### Ultimate SpartaRAT C# Project
# Info
This RAT project made for fun, I work on updates often.
I started with this project because I had so many ideas, with code I can be creative. This project is still under work, I will add alot more features.
I update this project very often.

**I will greatly appreciate all those who could invest their time in PR (Pull Request) or CR (Code Review) my project.**

# Why SpartaRAT is better than the others?
- Anti Virus bypass - True for today there is no anti virus that detects my program
- ESP32 Real life boards support - You can do really cool things
- Persistence (using task scheduler)
- .NET Framework - tested at the latest windows 11, 10, 8.1 versions
- Open source & Easy to contact the developer
- Really well written code, easy and fun to read, learn, or debugging
- Home made code - I am the one who write almost all the code, not ChatGPT or forums

  **Alot more stuff will be added soon.**

# Desktop C&C Server
![image](https://github.com/DanielSparta/2024-RAT-projet/assets/111179755/21ed04f8-30e4-49c7-95a0-9231817bb765)

![image](https://github.com/DanielSparta/2024-RAT-projet/assets/111179755/d228432f-87b1-4a0e-8c2f-5643d0385c13)

# ![image](https://github.com/DanielSparta/2024-RAT-projet/assets/111179755/78b29c43-c1ec-44ad-8c72-1369ed527d64)
- Screen Stream
- Screen Click
- Screen Draw
- Remote Shell
- Computer speech from text
- Screen Lock (Also working after computer restart **there are some bugs with it that I need to fix at my free time**)
- Camera Stream (ESP32 Arduino IDE ~ AI Thinker camera module)
- Keylogger
- ESP32 Board camera + bomb explode button
  
**_Alot More Features Soon_**
**_I would really appreciate any CR or ideas_**


**To run the program from virtual machine or from Visual studio, remove this function call**
![image](https://github.com/DanielSparta/2024-RAT-projet/assets/111179755/379831ad-8b4e-4536-8141-f0f4647fad70)



## ESP32-Cam Requirements
- You must compile the code into the esp32 cam by yourself
- Atleast Arduino IDE 1.x or any other compiler
- install board - Arduino AVR Boards (by Arduino)
- install board - ESP32 board (by Espressif Systems)
- Choosing Board - AI Thinker ESP32-CAM
- Choosing the right USB port
- Making sure the RAT and the ESP32-Cam are connected to the same WIFI

**_Then, Compile._**


## Fun fact
- I presented this project as a final project of an electronics major

![image](https://github.com/DanielSparta/2024-RAT-projet/assets/111179755/205d6626-1d0c-4f0d-a724-c0c631e00174)


## Legacy version
Legacy version of SpartaRAT (https://github.com/DanielSparta/RAT-Project-2022) - Created in 2022.

## Authors
- [@DanielSparta](https://github.com/DanielSparta)

